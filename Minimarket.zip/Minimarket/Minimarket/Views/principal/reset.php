<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restablecer Contraseña</title>

    <link rel="shortcut icon" href="<?php echo BASE_URL; ?>public/img/favicon.png">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>public/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>public/css/style.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>public/css/toastify.min.css">
</head>

<body>

    <main class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="card shadow">
                    <div class="card-body text-center">
                        <img src="<?php echo BASE_URL; ?>public/img/logo.png" height="60" alt="Logo">
                        <h4 class="my-3">Restablecer Contraseña</h4>

                        <form id="formulario" autocomplete="off">
                            <input type="hidden" id="token" name="token" value="<?php echo $data['seguridad']['token']; ?>">

                            <div class="form-group">
                                <input class="form-control" id="nueva" name="nueva" type="password" required placeholder="Nueva clave">
                            </div>

                            <div class="form-group">
                                <input class="form-control" id="confirmar" name="confirmar" type="password" required placeholder="Confirmar clave">
                            </div>

                            <div class="form-group mt-4">
                                <button class="btn btn-primary btn-block" type="submit">Restablecer</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </main>

    <script>
        const base_url = '<?php echo BASE_URL; ?>';
    </script>
    <script src="<?php echo BASE_URL; ?>public/js/jquery.min.js"></script>
    <script src="<?php echo BASE_URL; ?>public/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo BASE_URL; ?>public/js/toastify-js.js"></script>
    <script src="<?php echo BASE_URL; ?>public/js/page/reset.js"></script>
</body>

</html>
