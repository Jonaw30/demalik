<?php
const BASE_URL = "http://localhost/Minimarket/";
const HOST = "localhost";
const USER = "root";
const PASS = "";
const DB = "minimarket";
const CHARSET = "charset=utf8";
const TITLE = "Minimarket Demalik";
const MONEDA = "PEN";
const CLIENT_ID = "AfyCuBrR9OmZBXaVYblGKgUv8ucPtjcQbDekIKjWn6beRfpYAFVkx-h5yuzAtmAEGWvauK_Kc25MpOWb";
?>